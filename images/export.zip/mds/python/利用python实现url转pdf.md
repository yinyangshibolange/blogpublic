# 转换url为pdf

## 第一步：安装依赖和软件
需要用到两个东西，一个pdfkit 的 python 依赖，另一个是名为wkhtmltopdf的软件，
### 安装步骤
1. pdfkit安装，直接在命令行中执行pip install pdfkit即可
2. wkhtmltopdf安装：需要前往wkhtmltopdf官方下载网站https://wkhtmltopdf.org/downloads.html
然后根据你的系统下载对应的软件，我的是windows系统，所以下载的是后缀名是.exe的软件，

ps：我感觉这个软件比一些脚本/依赖好用很多，而且这个软件有mac版本，windows版本，linux版本，所以这个软件用于生产环境都可以，不过这种软件一般产生一定的内存消耗，一定要考虑服务器性能酌情使用

## 第二步编写python脚本

1. 导入pdfkit

```python
import pdfkit
```

2. 编写执行函数

```python
def url_to_pdf(url, to_file):
    # 将wkhtmltopdf.exe程序绝对路径传入config对象
    path_wkthmltopdf = r'C:Program Fileswkhtmltopdfinwkhtmltopdf.exe'
    config = pdfkit.configuration(wkhtmltopdf=path_wkthmltopdf)
    # 生成pdf文件，to_file为文件路径
    pdfkit.from_url(url, to_file, configuration=config)
    print('完成')
```

3. 执行函数

```python
url_to_pdf(r'https://zhuanlan.zhihu.com/p/69869004', 'out_1.pdf')
```