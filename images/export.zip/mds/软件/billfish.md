# billfish

* billfish是一个图片管理软件，他的好处是可以把我们项目中的素材统一到软件中进行管理，方便我们进行操作，
* billfish搭配浏览器采集插件，可以很轻松的采集浏览器中的图片到软件中，方便我们采集图片素材
* billfish具有云端同步功能，只要关注公众号即可免费使用

## 客户端

地址[Billfish3.0软件下载- Billfish素材管理工具](https://www.billfish.cn/product)

## 浏览器插件

地址[Billfish浏览器采集插件-创意设计必备素材管理工具](https://www.billfish.cn/extension)

## 食用方法

1. 下载安装并打开软件
2. 下载并安装浏览器插件
3. 将鼠标移动到图片位置按住鼠标并拖拽，就会显示如下对话框，将图片拖拽到对话框中即可收集此图片
![image.png](http://rqisd4yi1.hd-bkt.clouddn.com/20230322100057.png)
4. 打开软件即可看到刚刚用插件保存的图片

 ![image.png](http://rqisd4yi1.hd-bkt.clouddn.com/20230322100340.png)

